# ATT-Quest-Manager
CJ's ATT Quest Manager -  an application to help users with working with prefabs, along with other functionality.

This is still the early days, so more in-depth guides and new functionality are on their way.

To use, download the .zip, extract, enter your account name, password and server ID into Login.txt.
Make sure someone is on your server when you try to connect, otherwise the connection will fail and the application will close.

Any requests or bug reports? DM  CJ (Siege)#8147  on Discord. Please be patient.

This was inspired by The Prefabulator by Twidge - a vastly superior tool that works for ATT PC servers.

A video guide can be found here: https://youtu.be/avu4YZLFfik

/////////////////////////////////

Update Notes 10th Nov 2022:

So I've updated it with some new features. 

I'll make another video guide when I have some free time. 

The teleport images aren't great due to a bug with the game, but I'll replace them when the bug has been fixed.

Seriously though, DM me if you have any questions or issues through Discord. But if you just start with "hi", I will probably ignore it, not realising why you are messaging me.
